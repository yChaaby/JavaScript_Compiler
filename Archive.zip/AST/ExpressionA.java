package AST;

public abstract class ExpressionA extends Commande {
    public abstract Object evaluate();
}
