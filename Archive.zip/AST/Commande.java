package AST;
public abstract class Commande extends AST{
    public abstract String toAssembly();
}


