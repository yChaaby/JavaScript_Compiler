
package AST;
import java.util.Deque;
import java.util.ArrayDeque;

public abstract class AST{


    // vous pouvez ajouter ici les méthodes disponible sur tous les noeuds de vos ASTs    

}
