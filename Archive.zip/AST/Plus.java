package AST;

public class Plus extends ExpressionA_Binaire {

public Plus(ExpressionA gauche,ExpressionA droite) {super(gauche, droite);}
    
public String symbole(){
    return "plus";
};
public String toAssembly() {
    String gauche = this.gauche.toAssembly();
    String droite = this.droite.toAssembly();
    if(this.gauche instanceof Bool){
        gauche += "BoToNb\n";
    }else if(this.gauche instanceof Undefined){
        gauche += "Drop\nCsteNb NaN\n";
    }else if(this.gauche instanceof Ident){
        gauche += "TypeOf\n" +
                "Case\n" +
                "Error\n" +
                "Jump 4\n" +
                "Error\n" +
                "Error\n" +
                "Error\n" +
                "Error\n" +
                "Noop\n";
    }
    if(this.droite instanceof Bool){
        droite += "BoToNb\n";
    }else if(this.droite instanceof Undefined){
        droite += "Drop\nCsteNb NaN\n";
    }else if(this.droite instanceof Ident){
        droite += "TypeOf\n" +
                "Case\n" +
                "Error\n" +
                "Jump 4\n" +
                "Error\n" +
                "Error\n" +
                "Error\n" +
                "Error\n" +
                "Noop\n";
    }


    return gauche + droite + "AddiNb\n";
}


@Override
    public Object evaluate() {
        return (Integer) gauche.evaluate() + (Integer) droite.evaluate();
    }
}
