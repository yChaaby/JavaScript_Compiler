package AST;

public class Div extends ExpressionA_Binaire {

    public Div(ExpressionA gauche, ExpressionA droite) {
        super(gauche, droite);
    }

    public String symbole() {
        return "div";
    }
    public String toAssembly() {
        String gauche = this.gauche.toAssembly();
        String droite = this.droite.toAssembly();
        if(this.gauche instanceof Bool){
            gauche += "BoToNb\n";
        }else if(this.gauche instanceof Undefined){
            gauche += "Drop\nCsteNb NaN\n";
        }else if(this.gauche instanceof Ident){
            gauche += "TypeOf\n" +
                    "Case\n" +
                    "Error\n" +
                    "Jump 4\n" +
                    "Error\n" +
                    "Error\n" +
                    "Error\n" +
                    "Error\n" +
                    "Noop\n";
        }
        if(this.droite instanceof Bool){
            droite += "BoToNb\n";
        }else if(this.droite instanceof Undefined){
            droite += "Drop\nCsteNb NaN\n";
        }else if(this.droite instanceof Ident){
            droite += "TypeOf\n" +
                    "Case\n" +
                    "Error\n" +
                    "Jump 4\n" +
                    "Error\n" +
                    "Error\n" +
                    "Error\n" +
                    "Error\n" +
                    "Noop\n";
        }

        return gauche + droite + "DivNb\n";
    }

    @Override
    public Object evaluate() {
        Object leftValue = gauche.evaluate();
        Object rightValue = droite.evaluate();

        if (leftValue instanceof Integer && rightValue instanceof Integer) {
            return (Integer) leftValue / (Integer) rightValue;
        } else if (leftValue instanceof Float && rightValue instanceof Float) {
            return (Float) leftValue / (Float) rightValue;
        } else if (leftValue instanceof Integer && rightValue instanceof Float) {
            return (Integer) leftValue / (Float) rightValue;
        } else if (leftValue instanceof Float && rightValue instanceof Integer) {
            return (Float) leftValue / (Integer) rightValue;
        } else {
            throw new RuntimeException("Unsupported types for Div operation: " 
                + leftValue.getClass().getName() + " and " + rightValue.getClass().getName());
        }
    }
}
